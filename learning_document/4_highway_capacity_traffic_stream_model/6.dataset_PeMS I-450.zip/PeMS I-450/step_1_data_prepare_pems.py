# -*- coding: utf-8 -*-
"""
copyright: qixiu.cheng@seu.edu.cn

"""

import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt
import seaborn as sns

plt.rc('font',family='Times New Roman') 

# input data: flow、speed、occupancy
# DateTime: weekday on 2019/04，10:00~20:55
# Location:I-450 Abs 8.03~14.94

inputdir_flow = r'Data\\Flow'
df_flow = pd.DataFrame(
    columns=['Time', 'Postmile (Abs)', 'Postmile (CA)', 'VDS', 'AggFlow', '# Lane Points', '% Observed'])
for parents, dirnames, filenames in os.walk(inputdir_flow):
    for filename in filenames:
        df_flow_temp = pd.read_excel(os.path.join(parents, filename))
        df_flow = df_flow.append(df_flow_temp, ignore_index=True)  # missing the flow data on 12/04, Abs=14.59,12.89,11.02

inputdir_speed = r'Data\\Speed'
df_speed = pd.DataFrame(
    columns=['Time', 'Postmile (Abs)', 'Postmile (CA)', 'VDS', 'AggSpeed', '# Lane Points', '% Observed'])
for parents, dirnames, filenames in os.walk(inputdir_speed):
    for filename in filenames:
        df_speed_temp = pd.read_excel(os.path.join(parents, filename))
        df_speed = df_speed.append(df_speed_temp, ignore_index=True)  # # missing the speed data on 12/04, Abs=14.59,12.89,11.02

inputdir_occupancy = r'Data\\Occupancy'
df_occupancy = pd.DataFrame(
    columns=['Time', 'Postmile (Abs)', 'Postmile (CA)', 'VDS', 'AggOccupancy', '# Lane Points', '% Observed'])
for parents, dirnames, filenames in os.walk(inputdir_occupancy):
    for filename in filenames:
        df_occupancy_temp = pd.read_excel(os.path.join(parents, filename))
        df_occupancy = df_occupancy.append(df_occupancy_temp, ignore_index=True)  # # missing the occupancy data on 12/04, Abs=14.59,12.89,11.02

pd.date_range("10:00", "21:00", freq="5min").strftime('%H:%M')

# type reset
df_flow[['VDS', 'AggFlow', '# Lane Points']] = df_flow[['VDS', 'AggFlow', '# Lane Points']].astype('int')
df_speed[['VDS', 'AggSpeed', '# Lane Points']] = df_speed[['VDS', 'AggSpeed', '# Lane Points']].astype('int')
df_occupancy[['VDS', '# Lane Points']] = df_occupancy[['VDS', '# Lane Points']].astype('int')
df_occupancy[['AggOccupancy']] = df_occupancy[['AggOccupancy']].astype('float')

# to datetime
df_flow['Time'] = pd.to_datetime(df_flow['Time'],format='%H:%M').dt.time
df_speed['Time'] = pd.to_datetime(df_speed['Time'],format='%H:%M').dt.time
df_occupancy['Time'] = pd.to_datetime(df_occupancy['Time'],format='%H:%M').dt.time

# average the data for 22 weekdays at the same location and time
df_flow_avg_temp = df_flow.groupby(['Time', 'Postmile (Abs)'])[['AggFlow']].mean().reset_index()
df_speed_avg_temp = df_speed.groupby(['Time', 'Postmile (Abs)'])[['AggSpeed']].mean().reset_index()
df_occupancy_avg_temp = df_occupancy.groupby(['Time', 'Postmile (Abs)'])[['AggOccupancy']].mean().reset_index()

# reshape the data
df_flow_avg = df_flow_avg_temp.pivot('Postmile (Abs)','Time','AggFlow')
df_flow_avg.columns = pd.date_range("10:00", "20:55", freq="5min").strftime('%H:%M')
df_speed_avg = df_speed_avg_temp.pivot('Postmile (Abs)','Time','AggSpeed')
df_speed_avg.columns = pd.date_range("10:00", "20:55", freq="5min").strftime('%H:%M')
df_occupancy_avg = df_occupancy_avg_temp.pivot('Postmile (Abs)','Time','AggOccupancy')
df_occupancy_avg.columns = pd.date_range("10:00", "20:55", freq="5min").strftime('%H:%M')

# sort, traffic flow from botton to up
df_flow_avg = df_flow_avg.sort_index(ascending=False)
df_speed_avg = df_speed_avg.sort_index(ascending=False)
df_occupancy_avg = df_occupancy_avg.sort_index(ascending=False)

# plot the queue evolution profile
fig1 = plt.figure(figsize=(10,5))
sns.heatmap(df_speed_avg, vmin=0, vmax=60, center=0)
plt.ylabel('Vehicle detector locations', fontsize=18)
plt.title('Speed profile at I-450N', fontsize=22)
plt.show()
fig1.savefig('Queue profile.png', dpi=200, bbox_inches='tight')

# plot the speed-flow vs time
fig2 = plt.figure(figsize=(16,14))
plt.title('Speed and occupancy evolution at different locations')
plt.xticks([])
plt.yticks([])
for i in range(df_speed_avg.shape[0]-2):
    ax1 = fig2.add_subplot(5,4,i+1)
    df_speed_avg.iloc[i,].plot(style='b-',fontsize=5, linewidth=2)
    plt.vlines(39,10,65, colors = 'orange', linewidth=0.5, linestyles = "dashed")
    plt.vlines(118,10,65, colors = 'orange', linewidth=0.5, linestyles = "dashed") 
    plt.hlines(53,5,131, colors = 'g', linewidth=0.5, linestyles = "dashed") 
    ax2 = ax1.twinx()
    df_occupancy_avg.iloc[i,].plot(style='r-',fontsize=5, linewidth=2,)
plt.show()
fig2.savefig('Speed and occupancy evolution at different locations.png', dpi=300, bbox_inches='tight') 

fig3 = plt.figure(3)
plt.title('Speed and occupancy at the bottleneck')
ax1 = fig3.add_subplot(111)
df_speed_avg.iloc[5,].plot(style='b-',fontsize=8, linewidth=2)
plt.vlines(39,10,65, colors = 'orange', linewidth=0.5, linestyles = "dashed")
plt.vlines(118,10,65, colors = 'orange', linewidth=0.5, linestyles = "dashed") 
plt.hlines(53,5,131, colors = 'g', linewidth=0.5, linestyles = "dashed") # free flow speed = 53 mile/hour
plt.ylabel('Speed (mile/hour)', fontsize=10)
plt.text(25, 10, r't0=13:10')
plt.text(105, 10, r't3=19:45')
plt.text(43, 55, r'v=53mi/h')
ax2 = ax1.twinx()
df_occupancy_avg.iloc[5,].plot(style='r-',fontsize=8, linewidth=2)
plt.ylabel('Occupancy', fontsize=10)
plt.savefig('Speed and occupancy at the bottleneck.png', dpi=300, bbox_inches='tight')
plt.show()

fig4 = plt.figure(4)
plt.title('Speed and occupancy downstream the bottleneck')
ax1 = fig4.add_subplot(111)
df_speed_avg.iloc[4,].plot(style='b-',fontsize=8, linewidth=2)
plt.vlines(39,10,65, colors = 'orange', linewidth=0.5, linestyles = "dashed")
plt.vlines(118,10,65, colors = 'orange', linewidth=0.5, linestyles = "dashed") 
plt.hlines(53,5,131, colors = 'g', linewidth=0.5, linestyles = "dashed") # free flow speed = 53 mile/hour
plt.ylabel('Speed (mile/hour)', fontsize=10)
plt.text(25, 10, r't0=13:10')
plt.text(105, 10, r't3=19:45')
plt.text(43, 55, r'v=53mi/h')
ax2 = ax1.twinx()
df_occupancy_avg.iloc[4,].plot(style='r-',fontsize=8, linewidth=2,)
plt.ylabel('Occupancy', fontsize=10)
plt.savefig('Speed and occupancy downstream the bottleneck.png', dpi=300, bbox_inches='tight')
plt.show()

fig5 = plt.figure(5)
plt.title('Speed and occupancy upstream the bottleneck')
ax1 = fig5.add_subplot(111)
df_speed_avg.iloc[6,].plot(style='b-',fontsize=8, linewidth=2)
plt.vlines(39,10,65, colors = 'orange', linewidth=0.5, linestyles = "dashed")
plt.vlines(118,10,65, colors = 'orange', linewidth=0.5, linestyles = "dashed") 
plt.hlines(53,5,131, colors = 'g', linewidth=0.5, linestyles = "dashed") # free flow speed = 53 mile/hour
plt.ylabel('Speed (mile/hour)', fontsize=10)
plt.text(25, 10, r't0=13:10')
plt.text(105, 10, r't3=19:45')
plt.text(43, 55, r'v=53mi/h')
ax2 = ax1.twinx()
df_occupancy_avg.iloc[6,].plot(style='r-',fontsize=8, linewidth=2,)
plt.ylabel('Occupancy', fontsize=10)
plt.savefig('Speed and occupancy upstream the bottleneck.png', dpi=300, bbox_inches='tight')
plt.show()

fig6 = plt.figure(figsize=(12,8))
for i in range(df_flow_avg.shape[0]-2):
    plt.subplot(5,4,i+1)
    plt.scatter(list(df_occupancy_avg.iloc[i,0:92]), list(df_flow_avg.iloc[i,0:92]), s = 5, marker='o', c='', edgecolors='r')    # loading from 10:00 to 16:45
    plt.scatter(list(df_occupancy_avg.iloc[i,92:-1]), list(df_flow_avg.iloc[i,92:-1]), s = 5, marker='o', c='', edgecolors='b')  # unloading from 16:45 to 21:00
    plt.xticks(fontsize = 6)
    plt.yticks(fontsize = 6)
plt.show()
fig6.savefig('Critical occupancy.png', dpi=300, bbox_inches='tight')  

# determine the critical occupancy at each location
# crit_occ = np.array([0.16,0.11,0.10,0.14,0.10,0.13,0.15,0.12,0.13,0.13,0.13,0.13,0.13,0.12,0.12,0.13,0.12,0.10,0.13,0.10,0.15,0.20])
fig7 = plt.figure(7)
for i in range(df_flow_avg.shape[0]):
    plt.scatter(list(df_occupancy_avg.iloc[i,0:92]), list(df_flow_avg.iloc[i,0:92]), s = 6, marker='o', c='', edgecolors='r',label='loading')
    plt.scatter(list(df_occupancy_avg.iloc[i,92:-1]), list(df_flow_avg.iloc[i,92:-1]), s = 6, marker='o', c='', edgecolors='b',label='unloading')
    plt.xticks(fontsize = 8)
    plt.yticks(fontsize = 8)
    plt.xlabel('Occupancy')
    plt.ylabel('Number of vehicles per 5-min at location ' + str(i))
    plt.legend(loc=0)
    plt.show()

df_speed_avg.to_csv('speed.csv')
df_occupancy_avg.to_csv('occupancy.csv')
df_flow_avg.to_csv('flow.csv')
df_flow['# Lane Points'].iloc[0:22].to_csv('lanes.csv')


distance = np.zeros(df_flow_avg.shape[0])
distance[0] = 1/2*(np.array(df_flow['Postmile (Abs)'])[0] - np.array(df_flow['Postmile (Abs)'])[1])
distance[-1] = 1/2*(np.array(df_flow['Postmile (Abs)'])[-2] - np.array(df_flow['Postmile (Abs)'])[-1])
for i in range(1, len(distance)-1):
    distance[i] = 1/2*(np.array(df_flow['Postmile (Abs)'])[i-1] - np.array(df_flow['Postmile (Abs)'])[i+1])
np.savetxt('distance.csv', distance, delimiter = ',')

