# -*- coding: utf-8 -*-
"""
copyright: qixiu.cheng@seu.edu.cn

"""
import numpy as np
import pandas as pd
from scipy.optimize import minimize,fmin
import matplotlib.pyplot as plt
plt.rc('font',family='Times New Roman') 

# input data
num_lane_bottleneck = 4
df_flow_temp = pd.read_csv('flow.csv',index_col=0,header=0)
df_flow_temp2 = pd.read_csv('flow.csv',index_col=0,header=0)
df_speed_temp = pd.read_csv('speed.csv',index_col=0,header=0)
df_occupancy_temp = pd.read_csv('occupancy.csv',index_col=0,header=0)
df_distance_temp = pd.read_csv('distance.csv')
df_lanes_temp = pd.read_csv('lanes.csv',header=-1)
# 从 flow vs occupancy 可以大致得到 critical occupancy at different locations，我们这里只用一个值来代替
# crit_occ = np.array([0.16,0.11,0.10,0.14,0.10,0.13,0.15,0.12,0.13,0.13,0.13,0.13,0.13,0.12,0.12,0.13,0.12,0.10,0.13,0.10,0.15,0.20])
crit_occ = 0.13
# 从 Queue profile 以及 speed and occupancy at different locations 可以大致看出 bottleneck 位于 location 5 (Abs 13.51)
# 接下来只分析single bottleneck (location 5~14)，在congestion period的情况
t0 = 10+38/12   # t0=13:10:00
t3 = 10+117/12  # t3=19:44:59
P = t3 - t0     # P=6.583 hours
v_f = 53        # 从Speed and occupancy at the bottleneck得到的
v_mu = 20       # 从Speed and occupancy at different locations大致看出来的
L = 25          # 将occupancy转换成density时需要用到的参数，L=L_v+L_d，参见May_Page193公式(7.2)
factor_virQueue2phyQueue = 1 - v_mu/v_f    # 将virtual queue length转换成physical queue length

# 只分析single bottleneck (location 5~14)，在congestion period的情况
df_flow = df_flow_temp.iloc[5:15, 38:117]
df_speed = df_speed_temp.iloc[5:15, 38:117]
df_occupancy = df_occupancy_temp.iloc[5:15, 38:117]
df_lanes = df_lanes_temp.iloc[5:15, ]
df_distance = df_distance_temp.iloc[5:15, ]

# 得到observed cumulative departure curve
df_obs_cumu_departure = df_flow_temp.iloc[4, 38:117]
for i in range(1,len(df_obs_cumu_departure)):
    df_obs_cumu_departure[i] = df_obs_cumu_departure.iloc[i-1] + df_obs_cumu_departure.iloc[i]
    
# 得到observed queue length，先要将occupancy转化成density，参见May_Page193公式(7.2)
df_density = 5280/L*df_occupancy    # 单位：vehicles per lane-mile
crit_density = 5280/L*crit_occ
# 用density计算queue，参考May_Page217公式(7.16)
df_obs_queue_temp = df_density*0    
for i in range(df_density.shape[0]):
    for j in range(df_density.shape[1]):
        if np.array(df_density.iloc[i,j] - crit_density) < 0:
            df_density.iloc[i,j] = 0
        else:
            df_density.iloc[i,j] = df_density.iloc[i,j] - crit_density
        df_obs_queue_temp.iloc[i,j] = df_density.iloc[i,j]*df_lanes.iloc[i,1]*df_distance.iloc[i,0]
df_obs_queue = np.sum(df_obs_queue_temp,0)    # 注意这个queue是physical queue


# 得到observed delay，用速度来计算
df_travel_time_temp = df_speed*0
for i in range(df_speed.shape[0]):
    for j in range(df_speed.shape[1]):
        df_travel_time_temp.iloc[i,j] = df_distance.iloc[i,0]/df_speed.iloc[i,j]*60    # 单位是分钟
df_travel_time = np.sum(df_travel_time_temp, 0)
fftt = np.sum(df_distance,0)/v_f*60    # 单位是分钟
df_obs_delay = df_travel_time - np.array(fftt)    


# 用scipy.optimize里面的 minimize进行求解
t = np.linspace(t0, t3, num=len(df_obs_queue))
def objective(x,t,obs_cumu_departure,obs_queue,obs_delay,factor_virQueue2phyQueue):
    mu = x[0]
    gamma = x[1]
    m = x[2]
    t0 = t[0]
    t3 = t[-1]
    # 初始值
    N_t = np.zeros(len(obs_cumu_departure))
    Q_t = np.zeros(len(obs_queue))
    w_t = np.zeros(len(obs_delay))
    # 理论值
    for i in range(len(obs_cumu_departure)):
        N_t[i] = mu*(t[i] - t0 + 1/12)    # 1/12是因为每5分钟统计的数据
        Q_t[i] = 1/factor_virQueue2phyQueue*gamma*(t[i]-t0)**2*(0.25*(t[i]-t0)**2 - 1/3*((3-4*m)/(4-6*m)+m)*(t3-t0)*(t[i]-t0) + 1/2*(3-4*m)*m/(4-6*m)*((t3-t0)**2))
        w_t[i] = (1/mu)*gamma*(t[i]-t0)**2*(0.25*(t[i]-t0)**2 - 1/3*((3-4*m)/(4-6*m)+m)*(t3-t0)*(t[i]-t0) + 1/2*(3-4*m)*m/(4-6*m)*((t3-t0)**2))*60    # 这里同样是转换成分钟
        # calibrate queue的时候，需要将virtual queue转换成physical queue
        # 但是calibrate delay，不需要进行转换
    
    N_min_cal = mu/12
    N_max_cal = mu*(t3-t0)
    N_min_obs = obs_cumu_departure[0]
    N_max_obs = obs_cumu_departure[-1]
    
    Q_min_cal = min(Q_t)
    Q_max_cal = max(Q_t)
    Q_min_obs = min(obs_queue)
    Q_max_obs = max(obs_queue)
    
    w_min_cal = min(w_t)
    w_max_cal = max(w_t)
    w_min_obs = min(obs_delay)
    w_max_obs = max(obs_delay)
    
    f_val = 1/2*np.sum(((N_t-N_min_cal)/(N_max_cal-N_min_cal) - (obs_cumu_departure-N_min_obs)/(N_max_obs-N_min_obs))**2 \
                       + ((Q_t-Q_min_cal)/(Q_max_cal-Q_min_cal) - (obs_queue-Q_min_obs)/(Q_max_obs-Q_min_obs))**2 \
                       + ((w_t-w_min_cal)/(w_max_cal-w_min_cal) - (obs_delay-w_min_obs)/(w_max_obs-w_min_obs))**2)
    return f_val
    
def constraint1(x):
    t = np.linspace(13+10/60, 19+45/60, num=79)
    mu = x[0]
    gamma = x[1]
    m = x[2]
    t0 = t[0]
    t3 = t[-1]
    t2 = t0 + m*(t3-t0)
    t_bar = t0 + (3-4*m)*(t3-t0)/(4-6*m)
    inflow_rate = gamma*(t-t0)*(t-t2)*(t-t_bar) + mu
    return inflow_rate

# set initial values
# case 1: gamma>0,0.5<=m<2/3
x0 = np.array([3860,13,0.55])
bnds_mu = (3800, 4000)
bnds_gamma = (0, 1000)
bnds_m = (0.5,0.666667)
bnds = (bnds_mu, bnds_gamma, bnds_m)
'''
# case 2: gamma<0,2/3<m<=0.75
x0 = np.array([1200,-100,0.70])
bnds_mu = (1000, 7000)
bnds_gamma = (-999999, 0)
bnds_m = (0.666667,0.75)
bnds = (bnds_mu, bnds_gamma, bnds_m)
'''
# show initial objective
print('Initial Objective: ' + str(objective(x0,t,df_obs_cumu_departure,df_obs_queue,df_obs_delay,factor_virQueue2phyQueue)))

# optimize
con1 = {'type': 'ineq', 'fun': constraint1} 
cons = ([con1])
solution = minimize(objective, x0, args=(t,df_obs_cumu_departure,df_obs_queue,df_obs_delay,factor_virQueue2phyQueue), method='SLSQP', bounds=bnds, constraints=cons)
x = solution.x

# show final objective
print('Final Objective: ' + str(objective(x,t,df_obs_cumu_departure,df_obs_queue,df_obs_delay,factor_virQueue2phyQueue)))

# print solution
print('Solution: ')
print('mu = ' + str(x[0]))
print('gamma = ' + str(x[1]))
print('m = ' + str(x[2]))

# lambda/mu
def f1(t):
    return x[1]*(t-t0)*(t-t0-x[2]*(t3-t0))*(t-t0-(3-4*x[2])*(t3-t0)/(4-6*x[2])) + x[0]
def f2(t):
    return -x[1]*(t-t0)*(t-t0-x[2]*(t3-t0))*(t-t0-(3-4*x[2])*(t3-t0)/(4-6*x[2]))
min_lambda_over_mu = f1(fmin(f1,18.7))/x[0]
max_lambda_over_mu = (x[0] - f2(fmin(f2,14.5)))/x[0]
print('min_lambda_over_mu = ' + str(min_lambda_over_mu))
print('max_lambda_over_mu = ' + str(max_lambda_over_mu))


# Plot cumulative departure cueves
fig1 = plt.figure(1)
plt.plot(t, df_obs_cumu_departure,'b:', linewidth = 2, label = 'Observed values')
plt.plot(t, x[0]*(t - t0 + 1/12), 'r-', linewidth = 3, label = 'Calibrated values')
plt.xlabel('Time')
plt.ylabel('Cumulative number of vehicles')
plt.legend(loc=0)
plt.title('Calibration results of the cumulative departure curve')
plt.show()
fig1.savefig('Calibration of CD.png', dpi=300, bbox_inches='tight')

# Plot inflow rate
fig2 = plt.figure(2)
inflow_rate = x[1]*(t-t0)*(t-t0-x[2]*(t3-t0))*(t-t0-(3-4*x[2])*(t3-t0)/(4-6*x[2])) + x[0]
plt.plot(t, inflow_rate/num_lane_bottleneck, 'r-', linewidth=3, label = 'Inflow rate')
plt.hlines(x[0]/num_lane_bottleneck, t0, t3, colors = 'b', linestyles = 'dashed', linewidth=2, label = '$\mu$')
plt.ylabel('Number of vehicles (per hour per lane)', fontsize=12)
plt.ylim((700, 1150))
plt.legend(loc=0)
plt.title('Calibrated arrival rate and $\mu$', fontsize=16)
plt.show()
fig2.savefig('Inflow rate.png', dpi=300, bbox_inches='tight')

# Plot queue length
fig3 = plt.figure(3)
cal_queue_physical = 1/factor_virQueue2phyQueue*x[1]*(t-t0)**2*(0.25*(t-t0)**2 - 1/3*((3-4*x[2])/(4-6*x[2])+x[2])*(t3-t0)*(t-t0) + 1/2*(3-4*x[2])*x[2]/(4-6*x[2])*((t3-t0)**2))
plt.scatter(t, df_obs_queue, s = 2, marker='o', c='', edgecolors='b', label='Observed queue')
plt.plot(t, cal_queue_physical, 'r-', linewidth=3, label = 'Calibrated physical queue length')
plt.ylabel('Number of vehicles', fontsize=12)
plt.legend(loc=2)
plt.title('Calibration results of the queue length', fontsize=16)
plt.show()
fig3.savefig('Calibration of queue.png', dpi=300, bbox_inches='tight')

# Plot delay time
fig4 = plt.figure(4)
cal_delay = 60*(1/x[0]*x[1]*(t-t0)**2*(0.25*(t-t0)**2 - 1/3*((3-4*x[2])/(4-6*x[2])+x[2])*(t3-t0)*(t-t0) + 1/2*(3-4*x[2])*x[2]/(4-6*x[2])*((t3-t0)**2))) # 这里已经转换成分钟了
plt.scatter(t, df_obs_delay, s = 2, marker='o', c='', edgecolors='b', label='Observed delay')
plt.plot(t, cal_delay, 'r-', linewidth=3, label = 'Calibrated delay')
plt.xlabel('Time')
plt.ylabel('Delay time (min)')
plt.legend(loc=0)
plt.title('Calibration results of the delay time')
plt.show()
fig4.savefig('Calibration of delay.png', dpi=300, bbox_inches='tight')


# plot the mu
fig5 = plt.figure()
plt.scatter(t, 12/num_lane_bottleneck*df_flow_temp2.iloc[4,38:117], s = 2, marker='o', c='', edgecolors='b', label='Observed volume')
plt.hlines(x[0]/num_lane_bottleneck, t0, t3, colors = 'r', linewidth=3, label = '$\mu$')
plt.ylabel('Volume (per hour per lane)', fontsize=12)
plt.ylim((600, 1400))
plt.legend(loc=0)
plt.title('Calibration results of the $\mu$', fontsize=16)
plt.show()
fig5.savefig('Calibration of mu.png', dpi=300, bbox_inches='tight')
